﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using Senai.SP_Medical_Group.WebApi.Repositories;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

/// <summary>
/// Controller responsavel pelos endpoints referentes aos Consultas.
/// </summary>
namespace Senai.SP_Medical_Group.WebApi.Controllers
{
    //Define que o tipo de resposta da API será no formato JSON
    [Produces("application/json")]

    //Define que a rota de uma requisição será no formato domino/api/nomeController.
    // ex: http://localhost:5000/api/consultas
    [Route("api/[controller]")]

    //Define que é um controlador de API.
    [ApiController]
    public class ConsultasController : ControllerBase
    {


        /// <summary>
        /// Objeto _consultaRepository que irá receber todos os metodos definidor na interface IConsultaRepository
        /// </summary>
        private IConsultaRepository _consultaRepository { get; set; }

        /// <summary>
        /// Instancia um objeto _consultaRepository para que haja a referencia aos metodos no repositorio.
        /// </summary>
        public ConsultasController()
        {
            _consultaRepository = new ConsultaRepository();
        }

        /// <summary>
        /// Lista todas as Consultas
        /// </summary>
        /// <returns>Uma lista de Consultas e um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_consultaRepository.Listar());
        }

        /// <summary>
        /// Busca o id Consulta
        /// </summary>
        /// <returns>O id buscado um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet("{idConsulta}")]
        public IActionResult BuscarPorId(int idConsulta)
        {
            return Ok(_consultaRepository.BuscarPorId(idConsulta));
        }

        /// <summary>
        /// Cadastra um nova Consulta
        /// </summary>
        /// <returns>Um status code de que foi cadastrado o nova consulta.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Cadastrar(ConsultaDomain novaConsulta)
        {
            _consultaRepository.Cadastrar(novaConsulta);

            return StatusCode(201);
        }

        /// <summary>
        /// Deleta uma cosulta selecionado pelo id
        /// </summary>
        /// <returns>Status code que foi deletado a consulta escolhido pelo id.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpDelete("{idConsulta}")]
        public IActionResult Deletar(int idConsulta)
        {
            _consultaRepository.Deletar(idConsulta);

            return StatusCode(204);
        }

        /// <summary>
        /// Atualizar uma Consulta existente através do seu id
        /// </summary>
        /// <returns>Status code que foi atualizado.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPut("{idConsulta}")]
        public IActionResult Atualizar(short idConsulta, ConsultaDomain consultaAtualizada)
        {
            _consultaRepository.Atualizar(idConsulta, consultaAtualizada);

            return StatusCode(204);
        }



        /// <summary>
        /// Altera o status da situacao 
        /// </summary>
        /// <returns>Status code criado da situacao.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPatch("aprovar/{idConsulta}")]
        public IActionResult AprovarRecusar(int idConsulta, SituacaoDomain status)
        {
            try
            {
                _consultaRepository.AprovarRecusar(idConsulta, status.IdSituacao.ToString());
                return StatusCode(204);
            }
            catch (Exception error)
            {
                return BadRequest(error);

            }
        }

        /// <summary>
        /// Altera a descrição da consulta do medico 
        /// </summary>
        /// <param name="idConsulta">idConsulta paramentro sobre onde está a consulta</param>
        /// <param name="consulta">consulta objeto sobre a classe ConsultaDomain referente as variaveis</param>
        /// <returns>Status Code criado e que foi adicionado no banco as novas informações</returns>
        [Authorize(Roles = "2")]
        [HttpPatch("{idConsulta}")]
        public IActionResult AdicionarDescricao(int idConsulta, ConsultaDomain consulta)
        {
            _consultaRepository.AdicionarDescricao(idConsulta, consulta);

            return StatusCode(201);
        }
       
    }
}
