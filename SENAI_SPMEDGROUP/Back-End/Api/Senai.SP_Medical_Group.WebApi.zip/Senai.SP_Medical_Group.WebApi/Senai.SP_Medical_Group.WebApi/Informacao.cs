﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi
{
    public class Informacao
    {

        /*
      //percorre o caminho de Medicos ate a tabela consultas
      return ctx.Usuarios.Include(m => m.Medicos).ThenInclude(c => c.Consulta)
          //Compara o idUsuario recebido com o do banco de dados
          .Where(e => e.IdUsuario == idUsuario)
          //Retorna uma lista Medicos e consultas
          .ToList();

         //percorre o caminho de Pacientes ate a tabela consultas
        return ctx.Usuarios.Include(p=>p.Pacientes).ThenInclude(o=>o.Consulta)
                //Compara o idUsuario recebido com o do banco de dados
                .Where(h => h.IdUsuario == idUsuario)
                //Retorna uma lista Pacientes e consultas
                .ToList();
        */
    }
}
