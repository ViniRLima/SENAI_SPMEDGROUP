﻿using Senai.SP_Medical_Group.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Interfaces
{
    interface ILocalizacaoRepository
    {
        List<LocalizacaoDomain> ListarTodas();

        void Cadastrar(LocalizacaoDomain novaLocalizacao); 
    }
}
