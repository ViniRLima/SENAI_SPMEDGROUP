﻿using Senai.SP_Medical_Group.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Interfaces
{
    interface IMedicoRepository
    {
        
        /// <summary>
        /// Lista todos os Medicos
        /// </summary>
        /// <returns>Uma lista de Medicos</returns>
        List<MedicoDomain> Listar();

        /// <summary>
        /// Busca um Medico através do seu id
        /// </summary>
        /// <param name="idMedico">ID da Medico que será buscado</param>
        /// <returns>Um Medico encontrado</returns>
        MedicoDomain BuscarPorId(int idMedico);

        /// <summary>
        /// Cadastra um novo Medico
        /// </summary>
        /// <param name="novoMedico">Objeto novoMedico com os dados que serão cadastrados</param>
        void Cadastrar(MedicoDomain novoMedico);

        /// <summary>
        /// Atualiza um Medico existente
        /// </summary>
        /// <param name="idMedico">ID do medico que será atualizada</param>
        /// <param name="medicoAtualizado">Objeto medicoAtualizado com as novas informações</param>
        void Atualizar(short idMedico, MedicoDomain medicoAtualizado);

        /// <summary>
        /// Deleta um Medico existente
        /// </summary>
        /// <param name="idMedico">ID da Medico que será deletado</param>
        void Deletar(int idMedico);


    }
}
