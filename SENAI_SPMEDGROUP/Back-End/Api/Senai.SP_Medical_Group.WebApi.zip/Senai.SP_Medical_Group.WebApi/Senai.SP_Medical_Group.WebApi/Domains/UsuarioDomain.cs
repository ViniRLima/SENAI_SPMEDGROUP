﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class UsuarioDomain
    {
        public UsuarioDomain()
        {
            Medicos = new HashSet<MedicoDomain>();
            Pacientes = new HashSet<PacienteDomain>();
        }

        public int IdUsuario { get; set; }
        public int? IdTipoUsuario { get; set; }
        public string Usuario1 { get; set; }

        [Required(ErrorMessage = "O campo email é obrigatório")]
        public string Email { get; set; }

        [Required(ErrorMessage = "O campo senha é obrigatório")]
        public string Senha { get; set; }

        public virtual TipoUsuarioDomain IdTipoUsuarioNavigation { get; set; }
        public virtual ICollection<MedicoDomain> Medicos { get; set; }
        public virtual ICollection<PacienteDomain> Pacientes { get; set; }
    }
}
