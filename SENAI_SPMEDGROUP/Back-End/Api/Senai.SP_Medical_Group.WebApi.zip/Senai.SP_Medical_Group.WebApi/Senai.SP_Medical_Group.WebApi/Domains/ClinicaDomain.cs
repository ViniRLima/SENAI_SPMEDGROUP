﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class ClinicaDomain
    {
        public ClinicaDomain()
        {
            Medicos = new HashSet<MedicoDomain>();
        }

        public int IdClinica { get; set; }
        public string Clinica1 { get; set; }
        public string Cnpj { get; set; }
        public string RazaoSocial { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public TimeSpan HorarioInicio { get; set; }
        public TimeSpan HorarioFim { get; set; }

        public virtual ICollection<MedicoDomain> Medicos { get; set; }
    }
}
