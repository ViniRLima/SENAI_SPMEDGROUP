﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class Especialidade
    {
        public Especialidade()
        {
            Medicos = new HashSet<MedicoDomain>();
        }

        public int IdEspecialidade { get; set; }
        public string Especialidade1 { get; set; }

        public virtual ICollection<MedicoDomain> Medicos { get; set; }
    }
}
