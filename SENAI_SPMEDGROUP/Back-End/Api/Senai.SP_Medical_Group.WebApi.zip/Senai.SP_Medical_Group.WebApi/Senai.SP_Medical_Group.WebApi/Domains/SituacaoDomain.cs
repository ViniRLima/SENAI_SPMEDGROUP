﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class SituacaoDomain
    {
        public SituacaoDomain()
        {
            Consulta = new HashSet<ConsultaDomain>();
        }

        public int IdSituacao { get; set; }
        public string Situacao1 { get; set; }

        public virtual ICollection<ConsultaDomain> Consulta { get; set; }
    }
}
