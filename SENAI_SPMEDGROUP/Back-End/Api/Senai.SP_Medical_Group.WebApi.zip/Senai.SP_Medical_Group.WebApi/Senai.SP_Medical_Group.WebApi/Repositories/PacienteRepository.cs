﻿using Senai.SP_Medical_Group.WebApi.Contexts;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class PacienteRepository : IPacienteRepository
    {

        

        MedGroupContext ctx = new MedGroupContext();

        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="idPaciente">idPaciente irá receber valores no parametro da função</param>
        /// <param name="pacienteAtualizado">pacienteAtualizado irá receber valores no parametro da função</param>
        public void Atualizar(short idPaciente, PacienteDomain pacienteAtualizado)
        {
            PacienteDomain PacienteBuscado = ctx.Pacientes.Find(idPaciente);

            if (pacienteAtualizado.Paciente1 != null)
            {
                PacienteBuscado.Paciente1 = pacienteAtualizado.Paciente1;

                ctx.Pacientes.Update(PacienteBuscado);

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Buscar pelo id paciente
        /// </summary>
        /// <param name="idPaciente">Objeto idPaciente irá buscar o id pelas informações orientadas</param>
        /// <returns>O idPaciente buscado</returns>
        public PacienteDomain BuscarPorId(int idPaciente)
        {
            //Retorna o id buscado na consulta
            return ctx.Pacientes.FirstOrDefault(e => e.IdPaciente == idPaciente);
        }

        /// <summary>
        /// Cadastra um novo paciente
        /// </summary>
        /// <param name="novoPaciente">Objeto novoPaciente com as informações que serão cadastradas</param>
        public void Cadastrar(PacienteDomain novoPaciente)
        {
            // Adiciona um Paciente
            ctx.Pacientes.Add(novoPaciente);
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta um Paciente
        /// </summary>
        /// <param name="idPaciente">Objeto idPaciente que será deletado</param>
        public void Deletar(int idPaciente)
        {
            //Deleta uma Paciente
            ctx.Pacientes.Remove(BuscarPorId(idPaciente));
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas as Pacientes
        /// </summary>
        /// <returns>Lista de Consultas</returns>
        public List<PacienteDomain> Listar()
        {
            // Retorna uma listar de Pacientes
            return ctx.Pacientes.ToList();
        }

      

    }
}
