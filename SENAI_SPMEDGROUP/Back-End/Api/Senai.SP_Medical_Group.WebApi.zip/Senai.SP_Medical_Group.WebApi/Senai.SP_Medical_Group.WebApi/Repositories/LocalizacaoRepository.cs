﻿using MongoDB.Driver;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class LocalizacaoRepository : ILocalizacaoRepository
    {

        private readonly IMongoCollection<LocalizacaoDomain> _localizacao;

        public LocalizacaoRepository()
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("spmedgroup");
            _localizacao = database.GetCollection<LocalizacaoDomain>("mapas");
        }

        public void Cadastrar(LocalizacaoDomain novaLocalizacao)
        {
            _localizacao.InsertOne(novaLocalizacao);

        }

        public List<LocalizacaoDomain> ListarTodas()
        {
            return _localizacao.Find(localizacao => true).ToList();
        }
    }
}
