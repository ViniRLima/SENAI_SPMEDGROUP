﻿using Senai.SP_Medical_Group.WebApi.Contexts;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class ConsultaRepository : IConsultaRepository
    {
        

        MedGroupContext ctx = new MedGroupContext();

        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="idConsulta">idConsulta irá receber valores no parametro da função</param>
        /// <param name="consultaAtualizada">consultaAtualizada irá receber valores no parametro da função</param>
        public void Atualizar(short idConsulta, ConsultaDomain consultaAtualizada)
        {
            ConsultaDomain consultaBuscada = ctx.Consulta.Find(idConsulta);

            if (consultaAtualizada.Consulta != null)
            {
                consultaBuscada.Consulta = consultaAtualizada.Consulta;

                ctx.Consulta.Update(consultaBuscada);

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Buscar pelo id consulta
        /// </summary>
        /// <param name="idConsulta">Objeto idConsulta irá buscar o id pelas informações orientadas</param>
        /// <returns>O idConsulta buscado</returns>
        public ConsultaDomain BuscarPorId(int idConsulta)
        {
            //Retorna o id buscado na consulta
            return ctx.Consulta.FirstOrDefault(e => e.IdConsulta == idConsulta);
        }

        /// <summary>
        /// Cadastra um nova consulta
        /// </summary>
        /// <param name="novaConsulta">Objeto novaConsulta com as informações que serão cadastradas</param>
        public void Cadastrar(ConsultaDomain novaConsulta)
        {
            // Adiciona uma Consulta
            ctx.Consulta.Add(novaConsulta);
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta uma consulta
        /// </summary>
        /// <param name="idConsultas">Objeto idConsultas que será deletado</param>
        public void Deletar(int idConsultas)
        {
            //Deleta uma Consulta
            ctx.Consulta.Remove(BuscarPorId(idConsultas));
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas as Consultas
        /// </summary>
        /// <returns>Lista de Consultas</returns>
        public List<ConsultaDomain> Listar()
        {
            // Retorna uma listar de Consultas
            return ctx.Consulta.ToList();
        }


        /// <summary>
        /// Altera o status da situação
        /// </summary>
        /// <param name="idConsulta">idConsulta paramentro da idConsulta</param>
        /// <param name="status">status paramentro referente a situação</param>
        public void AprovarRecusar(int idConsulta, string status)
        {
            ConsultaDomain consultaBuscada = ctx.Consulta.FirstOrDefault(p => p.IdConsulta == idConsulta);

            switch (status)
            {

                case "1":
                    consultaBuscada.IdSituacao = 1;
                    break;

                case "2":
                    consultaBuscada.IdSituacao = 2;
                    break;

                case "3":
                    consultaBuscada.IdSituacao = 3;
                    break;

                default:
                    consultaBuscada.IdSituacao = consultaBuscada.IdSituacao;
                    break;
            }
            ctx.Consulta.Update(consultaBuscada);
            ctx.SaveChanges();
        }

      
        /// <summary>
        /// Adiciona uma nova descrição a coluna consulta que refere a descrição
        /// </summary>
        /// <param name="idConsulta">idConsulta paramentro da consulta</param>
        /// <param name="consulta">consulta paramentro referente a tabela Consulta</param>
        public void AdicionarDescricao(int idConsulta, ConsultaDomain consulta)
        {
            ConsultaDomain consultaBuscada = ctx.Consulta.Find(idConsulta);
            consultaBuscada.Consulta = consulta.Consulta;
            ctx.Consulta.Update(consultaBuscada);
            ctx.SaveChanges();
        }
    }


}
