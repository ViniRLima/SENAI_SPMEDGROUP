﻿using Senai.SP_Medical_Group.WebApi.Contexts;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class MedicoRepository : IMedicoRepository
    {
        

        MedGroupContext ctx = new MedGroupContext();

        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="idMedico">idMedico irá receber valores no parametro da função</param>
        /// <param name="medicoAtualizado">medicoAtualizado irá receber valores no parametro da função</param>
        public void Atualizar(short idMedico, MedicoDomain medicoAtualizado)
        {
            MedicoDomain MedicoBuscado = ctx.Medicos.Find(idMedico);

            if (medicoAtualizado.Medico1 != null)
            {
                MedicoBuscado.Medico1 = medicoAtualizado.Medico1;

                ctx.Medicos.Update(MedicoBuscado);

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Buscar pelo id medico
        /// </summary>
        /// <param name="idMedico">Objeto idMedico irá buscar o id pelas informações orientadas</param>
        /// <returns>O idMedico buscado</returns>
        public MedicoDomain BuscarPorId(int idMedico)
        {
            //Retorna o id buscado na consulta
            return ctx.Medicos.FirstOrDefault(e => e.IdMedico == idMedico);
        }

        /// <summary>
        /// Cadastra um novo medico
        /// </summary>
        /// <param name="novoMedico">Objeto novoMedico com as informações que serão cadastradas</param>
        public void Cadastrar(MedicoDomain novoMedico)
        {
            // Adiciona um Medico
            ctx.Medicos.Add(novoMedico);
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta um Medico
        /// </summary>
        /// <param name="idMedico">Objeto idMedico que será deletado</param>
        public void Deletar(int idMedico)
        {
            //Deleta um Medico
            ctx.Medicos.Remove(BuscarPorId(idMedico));
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas os Medicos
        /// </summary>
        /// <returns>Lista de Medicos</returns>
        public List<MedicoDomain> Listar()
        {
            // Retorna uma listar de Medicos
            return ctx.Medicos.ToList();
        }


      

    }
}
